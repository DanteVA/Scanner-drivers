==========================================================================
       TM-S9000 / S2000 Software

                                 Copyright(C) 2019 Seiko Epson Corporation
==========================================================================

1. About this software
This package provides software running on the following operating systems for TM-S9000/S2000.
1.1 Support OS
   Microsoft Windows 10 (32/64 bit)
   Microsoft Windows 8.1 (32/64 bit)
   Microsoft Windows 8 (32/64 bit)
   Microsoft Windows 7 SP1 (32/64 bit)
   Microsoft Windows Vista SP2 (32/64 bit)
   Microsoft Windows XP SP3 (32 bit)
   Microsoft Windows Server 2016
   Microsoft Windows Server 2012 R2
   Microsoft Windows Server 2012
   Microsoft Windows Server 2008 R2 SP1
   Microsoft Windows Server 2008 SP2 (32/64 bit)
   Microsoft Windows Embedded Standard 7 (32/64bit)
   Microsoft Windows XP Embedded (32bit)
   Microsoft Windows Embedded POS Ready 7 (32/64bit)
   Microsoft Windows Embedded POS Ready 2009 (32bit)

1.2 Support USB Host controllers
   Intel(R) USB Host controller with built-in chipset.
   NEC EHCI USB Host controller.

1.3 Support USB driver stacks
   Microsoft(R) USB driver stack which is included in OS.
   TMUSB does not support any third party driver stacks.

1.4 Support Device
   TM-S2000
   TM-S9000
   TM-S9000II
   TM-S2000II

2. Contents
 1) This package consists of the following folders.
    +- Setup   - TM-S9000/S2000 Driver
    +- Sample  - TM-S9000/S2000 Sample Programs of C++, VB6, C# and VB.NET
    +- Doc     - API Reference Guide

 2) README.TXT --- This readme file

3. Installation method
  1) TM-S9000/2000 Driver
     Please refer to API Reference Guide for Win32/64.
  2) TM-S9000/S2000 Sample Programs
     Please unzip TMS_Sample.zip

4. Restrictions
  The OS cannot be in Stand By or Sleep mode while the device is operating
  Please close scanning applications, or else power off the device before
  setting the OS to stand by/sleep/hibernation mode.
