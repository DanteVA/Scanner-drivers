==========================================================================
       TM-S2000 TWAIN Wrapper

                                 Copyright(C) 2015 SEIKO EPSON CORPORATION
==========================================================================

* NOTICE *
   You need to install TM-S2000 Driver that is separately provided when you use the TWAIN Wrapper.


1. Support OS
This package provides software running on the following operating systems for TM-S2000.
   Microsoft Windows 8.1 (32/64 bit)
   Microsoft Windows 8 (32/64 bit)
   Microsoft Windows 7 SP1 (32/64 bit)
   Microsoft Windows Vista SP2 (32/64 bit)
   Microsoft Windows XP SP3 (32 bit)
   Microsoft Windows Server 2012 R2
   Microsoft Windows Server 2012
   Microsoft Windows Server 2008 R2 SP1
   Microsoft Windows Server 2008 SP2 (32/64 bit)
   Microsoft Windows Embedded Standard 7 (32/64bit)
   Microsoft Windows Embedded Standard (32bit)
   Microsoft Windows Embedded POS Ready 7 (32/64bit)
   Microsoft Windows Embedded POS Ready 2009 (32bit)

2. Contents
 1) This package consists of the following folders.
    +- Setup   - TM-S2000 TWAIN Wrapper Ver.1.04
    +- Sample  - TWAIN Sample Program and source code written in C++.
    +- Doc     - TWAIN API Reference Guide

 2) README.TXT --- This readme file

3. Installation method
  1) TWAIN Wrapper
     - Install TM-S2000 Driver first.
     - Then install the TWAIN Wrapper.
       For details, please refer to TM-S9000S2000_TWAIN_en_revC.pdf.
  2) TWAIN Sample Program
     Please unzip TWAINSampleProgram.zip

End
